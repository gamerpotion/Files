DarkBindings Recipe Disabler

Visit - https://www.curseforge.com/minecraft/mc-mods/darkbindings-custom-recipes

Get the recipe name from the full recipe list section.

Then go into the data\darkbindings\recipes\  folder  and rename the blank (rename_me.json) json file into a name from the full recipe list

For example, if you wish to disable the End Portal Frame recipe,  rename the blank file into "end_portal_frame"   make sure the *.json extension is maintained for the file.
You should end up with a file that looks something like "end_portal_frame.json"  and be 0kb in size

You can disable multiple recipes this way, by just duplicating the blank file and renaming them into the names from the full recipe list section.

Place the datapack inside your world's "datapacks" folder and reload the world/server.