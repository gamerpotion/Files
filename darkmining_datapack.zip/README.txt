USE A TEXT EDITOR SUCH AS NOTEPAD++ AND EDIT THE FOLLOWING FILES:-

*.json files found in darkmining_datapack.zip\data\minecraft\loot_tables\blocks\


The following line indicates 100%. Increase the "100" value to lower the drop chance of all the items for a particular block

{ "type": "minecraft:empty","weight": 100}


You can also edit the "weight" of each item line to control its drop chance


-----------------
GamerPotion.net
