Place the datapack zip file inside your world's "datapacks" folder to enable.

To change the rewards:-

Open  data/darkrewards/loot_tables/darkrewards.json

In this file you will find a list of rewards.  

The id of the item will be written as "minecraft:apple".
Weight refers to how frequent you want the item to be given. Higher the weight, the more it will be given out. Lower weight means its rarer.
Count refers to the number of items.

Simply replace the id's with another id of an item you want to be given. You can add or delete lines as required making sure there is a , (comma) after each line.
Note: the last line does not have a , (comma).

Once everything has been updated and saved and if zip file is in the datapacks folder, then restart your world or use the /reload command (admin only) and it will take effect.