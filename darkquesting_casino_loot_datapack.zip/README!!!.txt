Instructions on how to change the DarkQuesting Casino Loot table
-------------------

Open data -> darkrpg -> loot_tables -> casino.json  (using a txt editor)

To change existing items, replace the item name ID fully making sure you do not miss any coding before or after it.

For example if you wanted to replace the elytra with an apple, you would find "minecraft:elytra" and replace it with "minecraft:apple"

You can then change its quantity by changing "count": 1  into "count": 10 (found towards the end of the line) to reward 10x apples

The weight determines how common the item will appear in the casino spins. Higher weight means it will appear more. So for the apply if you change "weight": 1  into  "weight": 20,  it will drop more apples than any other item when a player spins.

Note: each complete line is to be ended with a comma. The last line (stone) does not have a comma at the end of it. Be careful when deleting a full line or adding a new line to not miss out the coding.