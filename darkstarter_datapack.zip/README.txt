USE A TEXT EDITOR SUCH AS NOTEPAD++ AND EDIT THE FOLLOWING FILES:-

data/rewards/functions/rewards.mcfunction (Text displayed in chat when player logs into game)

data/rewards/loot_tables/rewards.json (Items received inside bundle)

Note:-
- you can add more items by copying one of the lines and changing the values
- there should be no comma after the last item line in the loot table file
- be mindful of the total item space in the chest
- any incorrect item IDs used will result in datapack not working

-----------------
GamerPotion.net
