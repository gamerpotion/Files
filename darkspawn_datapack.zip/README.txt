USE A TEXT EDITOR SUCH AS NOTEPAD++ AND EDIT THE FOLLOWING FILES:-

data/darkspawn/functions/darkspawntick.mcfunction (Focus on the 3rd line)

Change the coordinates from `20 100 20` to anything you want and upload this datapack file to the 'datapacks' folder of your world.
Server users make sure to restart your server or use /reload for it to take effect.

-----------------
GamerPotion.net
